#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define NUM_PASSWORDS 10

struct password {
  char account[256];
  char username[128];
  char password[512];
  int is_set;
};

struct password passwords[NUM_PASSWORDS];

void die(char * msg) {
	printf("%s\n", msg);
	exit(1);
}

void read_flag() {
  int fd;

  fd = open("flag.txt", O_RDONLY);
  if(fd < 0) {
    puts("Couldn't open flag file\n");
    exit(1);
  }
  if(read(fd, passwords[0].password, sizeof(passwords[0].password)) < -1) {
    puts("Couldn't read flag file\n");
    exit(1);
  }
  close(fd);

  strcpy(passwords[0].account, "flag@flag.flag");
  strcpy(passwords[0].username, "flag");
  passwords[0].is_set = 1;
}

char * read_line(char * buffer, int length) {
  int i;
  for(i = 0; i < length; i++) {
    if(read(0, buffer + i, 1) != 1)
      break;

    if(buffer[i] == '\n') {
      buffer[i] = 0;
      return buffer;
    }
  }

  exit(1);
}

int read_int() {
  char buffer[64];
  return atoi(read_line(buffer, sizeof(buffer)));
}

int main_menu(void) {
  puts(
    "Password Manager Menu:\n"
    "0) List all passwords\n"
    "1) Add a password\n"
    "2) Remove a password\n"
    "3) Update a password\n"
    "4) Print password\n"
    "9) Leave\n"
  );
  return read_int();
}

void list(void) {
  int i;

  puts("\nPasswords:");
  puts("Row - Account              - Username             - Password");
  puts("============================================================");
  for(i = 0; i < NUM_PASSWORDS; i++) {
    if(!passwords[i].is_set)
      continue;
    printf("%-3d - %-20s - %-20s - ********\n", i, passwords[i].account,
      passwords[i].username);
  }
  printf("\n");
}

void add(void)
{
  int i, item = -1;
  char account[64];
  char password[64];
  char username[64];

  for(i = 0; i < NUM_PASSWORDS && item == -1; i++) {
    if(!passwords[i].is_set)
      item = i;
  }

  if(item == -1) {
    printf("Password Manager Free can only supports %d passwords. "
      "Please upgrade to store additional passwords\n", NUM_PASSWORDS);
    return;
  }

  puts("Account?");
  read_line(account, sizeof(passwords[item].account));
  puts("Username?");
  read_line(username, sizeof(passwords[item].username));
  puts("Password?");
  read_line(password, sizeof(passwords[item].password));
  
  passwords[item].is_set = 1;
  strncpy(passwords[item].account, account, sizeof(passwords[item].account));
  strncpy(passwords[item].username, username, sizeof(passwords[item].username));
  strncpy(passwords[item].password, password, sizeof(passwords[item].password));
}

void delete(void)
{
  int item;

  puts("What row would you like to remove?");
  item = read_int();
  if(item < 0 || item >= NUM_PASSWORDS)
    exit(1);
  if(!passwords[item].is_set)
    exit(1);

  passwords[item].is_set = 0;
}

void update(void)
{
  int item;

  puts("What row would you like to update?");
  item = read_int();
  if(item < 0 || item >= NUM_PASSWORDS)
    exit(1);
  if(!passwords[item].is_set)
    exit(1);

  puts("What is the new password?");
  read_line(passwords[item].password, sizeof(passwords[item].password));
}

void print(void)
{
  int item;

  puts("What row would you like to print?");
  item = read_int();
  if(item < 0 || item >= NUM_PASSWORDS)
    exit(1);
  if(!passwords[item].is_set)
    exit(1);

  if(item == 0) {
    puts("ACCESS DENIED!");
  } else {
    puts("\nRow - Account              - Username             - Password");
    printf("%-3d - %-20s - %-20s - %s\n", item, passwords[item].account,
      passwords[item].username, passwords[item].password);
    puts("\n");
  }
}

int main(int argc, char ** argv)
{
  int choice;

  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);
  alarm(60);

  memset(&passwords, 0, sizeof(passwords));
  read_flag();

  puts("Welcome to Password Saver 3.9");
  choice = 0;
  while(choice != 9) {
    choice = main_menu();
    switch(choice) {
      case 0:
        list();
        break;
      case 1:
        add();
        break;
      case 2:
        delete();
        break;
      case 3:
        update();
        break;
      case 4:
        print();
        break;
    }
  }

  return 0;
}
