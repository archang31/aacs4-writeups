import java.util.ArrayList;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.ClassNotFoundException;
import java.net.ServerSocket;
import java.net.Socket;
import java.*;
import java.lang.System;

import org.apache.commons.collections4.*;
import org.apache.commons.collections4.CollectionUtils;

public class Server {

    public static void main(String args[]) throws IOException, ClassNotFoundException {     
        System.setSecurityManager(null);
        // Create example notes
        Note note1 = new Note(1, "Test", "This is the main content");
        Note note2 = new Note(2, "Shopping list", "Milk\nEggs\nSausage");
        Note note3 = new Note(3, "Bills", "Don't forget to pay the bills due on the 11th!");

        // Create list to store all notes
        ArrayList<Note> noteList = new ArrayList<Note>();
        noteList.add(note1);
        noteList.add(note2);
        noteList.add(note3);

        // Server loop
        while (true) {
            while(true){
                // Create streams
                ObjectInputStream ois = new ObjectInputStream(System.in);
                ObjectOutputStream oos = new ObjectOutputStream(System.out);
                
                // convert object from client to String so we can check it
                // not sure if this is safe...
                String message = (String) ois.readObject();

                if(message.equalsIgnoreCase("GET")){
                    // Client wants all of the saved notes
                    oos.writeObject(noteList);
                    continue;

                }else if (message.equalsIgnoreCase("SAVE")){
                    // Client wants to save a note, accept a Note object
                    Note newNote = (Note) ois.readObject();
                    noteList.add(newNote);
                    continue;

                }else if (message.equalsIgnoreCase("BYE")){
                    break;
                }else{
                    // Ignore
                }
            }
        }
    }
}
